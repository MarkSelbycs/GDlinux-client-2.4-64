#define _POSIX_C_SOURCE 200809L
#define _GNU_SOURCE

#include <dlfcn.h>
#include <errno.h>
#include <libxml/parser.h>
#include <libxml/tree.h>
#include <netdb.h>
#include <sys/socket.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <unistd.h>

typedef char *(*codec_function)(const char *);
typedef void (*free_function)(const char *);

struct buffer {
    char *data;
    size_t length;
};

struct portal_config {
    char *ticket_url;
    char *auth_url;
    char *client_id;
    char *user_agent;
    char *wlan_user_ip;
    char *wlan_user_mac;
    char *wlan_ac_ip;
    char *school_id;
    char *domain;
    char *area;
};

struct codec {
    void *module;
    codec_function code;
    codec_function decode;
    free_function release;
};

static const char *default_config_url =
    "http://14.146.227.141:7001/detect.html";
static const char *default_portal_url =
    "http://125.88.59.131:10001/qs/index_gz.jsp?"
    "wlanacip=183.3.151.148&wlanuserip=172.17.104.132";

static void buffer_free(struct buffer *buffer)
{
    free(buffer->data);
    buffer->data = NULL;
    buffer->length = 0;
}

static int append_bytes(struct buffer *buffer, const char *data, size_t bytes)
{
    char *grown = realloc(buffer->data, buffer->length + bytes + 1);

    if (grown == NULL) {
        return 0;
    }
    memcpy(grown + buffer->length, data, bytes);
    buffer->data = grown;
    buffer->length += bytes;
    buffer->data[buffer->length] = '\0';
    return 1;
}

static int decode_chunked_body(struct buffer *buffer)
{
    char *decoded = malloc(buffer->length + 1);
    size_t input = 0;
    size_t output = 0;

    if (decoded == NULL) {
        return 0;
    }
    while (input < buffer->length) {
        char *line_end = strstr(buffer->data + input, "\r\n");
        unsigned long chunk_size;
        char *end;

        if (line_end == NULL) {
            free(decoded);
            return 0;
        }
        *line_end = '\0';
        chunk_size = strtoul(buffer->data + input, &end, 16);
        if (end == buffer->data + input || *end != '\0') {
            free(decoded);
            return 0;
        }
        input = (size_t)(line_end - buffer->data) + 2;
        if (chunk_size == 0) {
            break;
        }
        if (chunk_size > buffer->length - input ||
            buffer->length - input - chunk_size < 2) {
            free(decoded);
            return 0;
        }
        memcpy(decoded + output, buffer->data + input, (size_t)chunk_size);
        output += (size_t)chunk_size;
        input += (size_t)chunk_size + 2;
    }
    decoded[output] = '\0';
    free(buffer->data);
    buffer->data = decoded;
    buffer->length = output;
    return 1;
}

static int parse_http_url(const char *url, char **host, char **port,
                          char **path)
{
    const char *start;
    const char *slash;
    const char *colon;
    size_t host_length;
    size_t port_length;

    if (strncmp(url, "http://", 7) != 0) {
        return 0;
    }
    start = url + 7;
    slash = strchr(start, '/');
    if (slash == NULL) {
        slash = start + strlen(start);
    }
    colon = memchr(start, ':', (size_t)(slash - start));
    host_length = (size_t)((colon == NULL ? slash : colon) - start);
    if (host_length == 0) {
        return 0;
    }
    *host = strndup(start, host_length);
    if (colon == NULL) {
        *port = strdup("80");
    } else {
        port_length = (size_t)(slash - colon - 1);
        *port = strndup(colon + 1, port_length);
    }
    *path = strdup(*slash == '\0' ? "/" : slash);
    if (*host == NULL || *port == NULL || *path == NULL) {
        free(*host);
        free(*port);
        free(*path);
        return 0;
    }
    return 1;
}

static int send_all(int descriptor, const char *data, size_t length)
{
    while (length != 0) {
        ssize_t written = send(descriptor, data, length, 0);
        if (written <= 0) {
            return 0;
        }
        data += written;
        length -= (size_t)written;
    }
    return 1;
}

static int http_request(const char *url, const char *post_data,
                        const char *user_agent, struct buffer *response,
                        long *status, const char *cookie, char **new_cookie)
{
    struct addrinfo hints = {0};
    struct addrinfo *addresses = NULL;
    struct addrinfo *address;
    char *host = NULL;
    char *port = NULL;
    char *path = NULL;
    char *request = NULL;
    char *separator;
    int descriptor = -1;
    int connected = 0;
    char receive_buffer[8192];
    ssize_t received;
    size_t header_length;
    int chunked;
    const char *cookie_prefix = cookie == NULL ? "" : "Cookie: ";
    const char *cookie_value = cookie == NULL ? "" : cookie;
    const char *cookie_suffix = cookie == NULL ? "" : "\r\n";

    if (!parse_http_url(url, &host, &port, &path)) {
        return 0;
    }
    hints.ai_socktype = SOCK_STREAM;
    if (getaddrinfo(host, port, &hints, &addresses) != 0) {
        goto cleanup;
    }
    for (address = addresses; address != NULL; address = address->ai_next) {
        descriptor = socket(address->ai_family, address->ai_socktype,
                            address->ai_protocol);
        if (descriptor >= 0 && connect(descriptor, address->ai_addr,
                                       address->ai_addrlen) == 0) {
            connected = 1;
            break;
        }
        close(descriptor);
        descriptor = -1;
    }
    if (!connected) {
        goto cleanup;
    }
    if (post_data == NULL) {
        if (asprintf(&request, "GET %s HTTP/1.1\r\nHost: %s\r\nUser-Agent: %s\r\n"
                     "Accept: text/html,text/xml,application/xhtml+xml,application/xml,*/*\r\n"
                     "Connection: close\r\n%s%s%s\r\n", path, host, user_agent,
                     cookie_prefix, cookie_value, cookie_suffix) < 0) {
            goto cleanup;
        }
    } else if (asprintf(&request, "POST %s HTTP/1.1\r\nHost: %s\r\nUser-Agent: %s\r\n"
                        "Accept: text/html,text/xml,application/xhtml+xml,application/xml,*/*\r\n"
                        "Content-Type: text/xml; charset=UTF-8\r\nConnection: close\r\n"
                        "Content-Length: %zu\r\n%s%s%s\r\n%s", path, host,
                        user_agent, strlen(post_data), cookie_prefix, cookie_value,
                        cookie_suffix, post_data) < 0) {
        goto cleanup;
    }
    if (!send_all(descriptor, request, strlen(request))) {
        goto cleanup;
    }
    while ((received = recv(descriptor, receive_buffer,
                            sizeof(receive_buffer), 0)) > 0) {
        if (!append_bytes(response, receive_buffer, (size_t)received)) {
            goto cleanup;
        }
    }
    separator = strstr(response->data == NULL ? "" : response->data,
                       "\r\n\r\n");
    if (separator == NULL || sscanf(response->data, "HTTP/%*s %ld", status) != 1) {
        goto cleanup;
    }
    if (new_cookie != NULL) {
        char *cookie_start = strcasestr(response->data, "Set-Cookie:");
        if (cookie_start != NULL) {
            char *cookie_end;

            cookie_start += strlen("Set-Cookie:");
            while (*cookie_start == ' ') {
                ++cookie_start;
            }
            cookie_end = strpbrk(cookie_start, ";\r\n");
            if (cookie_end != NULL) {
                free(*new_cookie);
                *new_cookie = strndup(cookie_start,
                                      (size_t)(cookie_end - cookie_start));
            }
        }
    }
    chunked = strcasestr(response->data, "Transfer-Encoding: chunked") != NULL;
    header_length = (size_t)(separator + 4 - response->data);
    memmove(response->data, response->data + header_length,
            response->length - header_length + 1);
    response->length -= header_length;
    if (chunked && !decode_chunked_body(response)) {
        goto cleanup;
    }
    connected = *status >= 200 && *status < 400;

cleanup:
    if (descriptor >= 0) {
        close(descriptor);
    }
    freeaddrinfo(addresses);
    free(host);
    free(port);
    free(path);
    free(request);
    return connected;
}

static char *node_text(xmlNodePtr root, const char *name)
{
    xmlNodePtr node;
    xmlChar *content;

    if (root == NULL) {
        return NULL;
    }
    if (root->type == XML_ELEMENT_NODE &&
        xmlStrcasecmp(root->name, (const xmlChar *)name) == 0) {
        content = xmlNodeGetContent(root);
        if (content != NULL && content[0] != '\0') {
            return (char *)content;
        }
        xmlFree(content);
        return NULL;
    }
    for (node = root->children; node != NULL; node = node->next) {
        xmlChar *content;

        if (node->type != XML_ELEMENT_NODE ||
            xmlStrcasecmp(node->name, (const xmlChar *)name) != 0) {
            continue;
        }
        content = xmlNodeGetContent(node);
        if (content == NULL || content[0] == '\0') {
            xmlFree(content);
            return NULL;
        }
        return (char *)content;
    }
    return NULL;
}

static char *find_text(xmlNodePtr root, const char *first, const char *second)
{
    char *value = node_text(root, first);
    return value != NULL ? value : node_text(root, second);
}

static int set_value(char **destination, char *value)
{
    free(*destination);
    *destination = value;
    return value != NULL;
}

static int parse_config(const char *data, struct portal_config *config)
{
    xmlDocPtr document = xmlReadMemory(data, (int)strlen(data), NULL, NULL,
                                       XML_PARSE_NONET | XML_PARSE_NOERROR);
    xmlNodePtr root;

    if (document == NULL) {
        return 0;
    }
    root = xmlDocGetRootElement(document);
    if (root == NULL) {
        xmlFreeDoc(document);
        return 0;
    }
    set_value(&config->ticket_url, find_text(root, "tickUrl", "ticket-url"));
    set_value(&config->auth_url, find_text(root, "authUrl", "auth-url"));
    set_value(&config->client_id, find_text(root, "clientId", "client-id"));
    set_value(&config->wlan_user_ip, node_text(root, "wlanuserip"));
    set_value(&config->wlan_user_mac, node_text(root, "wlanusermac"));
    set_value(&config->wlan_ac_ip, node_text(root, "wlanacip"));
    set_value(&config->school_id, node_text(root, "schoolId"));
    set_value(&config->domain, node_text(root, "domain"));
    set_value(&config->area, node_text(root, "area"));
    if (config->auth_url == NULL && config->ticket_url != NULL) {
        const char *path = strstr(config->ticket_url, "/ticket.cgi");
        size_t prefix_length = path == NULL ? 0 : (size_t)(path - config->ticket_url);

        if (prefix_length != 0) {
            if (asprintf(&config->auth_url, "%.*s/auth.cgi",
                         (int)prefix_length, config->ticket_url) < 0) {
                config->auth_url = NULL;
            }
        }
    }
    xmlFreeDoc(document);
    return config->ticket_url != NULL && config->auth_url != NULL;
}

static char *read_file(const char *path)
{
    FILE *file = fopen(path, "rb");
    long length;
    char *data;

    if (file == NULL || fseek(file, 0, SEEK_END) != 0) {
        if (file != NULL) {
            fclose(file);
        }
        return NULL;
    }
    length = ftell(file);
    if (length < 0 || fseek(file, 0, SEEK_SET) != 0) {
        fclose(file);
        return NULL;
    }
    data = malloc((size_t)length + 1);
    if (data == NULL || fread(data, 1, (size_t)length, file) != (size_t)length) {
        free(data);
        fclose(file);
        return NULL;
    }
    data[length] = '\0';
    fclose(file);
    return data;
}

static char *query_value(const char *url, const char *name)
{
    char *marker;
    char *end;
    size_t length;

    marker = strstr(url, name);
    if (marker == NULL || (marker != url && marker[-1] != '?' && marker[-1] != '&') ||
        marker[strlen(name)] != '=') {
        return NULL;
    }
    marker += strlen(name) + 1;
    end = strpbrk(marker, "&#");
    length = end == NULL ? strlen(marker) : (size_t)(end - marker);
    return strndup(marker, length);
}

static char *replace_query_value(const char *url, const char *name,
                                 const char *value)
{
    char *marker = strstr(url, name);
    const char *value_start;
    const char *value_end;
    size_t prefix_length;
    size_t suffix_length;
    char *result;

    if (marker == NULL || (marker != url && marker[-1] != '?' && marker[-1] != '&') ||
        marker[strlen(name)] != '=') {
        return strdup(url);
    }
    value_start = marker + strlen(name) + 1;
    value_end = strpbrk(value_start, "&#");
    if (value_end == NULL) {
        value_end = url + strlen(url);
    }
    prefix_length = (size_t)(value_start - url);
    suffix_length = strlen(value_end);
    result = malloc(prefix_length + strlen(value) + suffix_length + 1);
    if (result == NULL) {
        return NULL;
    }
    memcpy(result, url, prefix_length);
    memcpy(result + prefix_length, value, strlen(value));
    memcpy(result + prefix_length + strlen(value), value_end, suffix_length);
    result[prefix_length + strlen(value) + suffix_length] = '\0';
    return result;
}

static void config_free(struct portal_config *config)
{
    free(config->ticket_url);
    free(config->auth_url);
    free(config->client_id);
    free(config->user_agent);
    free(config->wlan_user_ip);
    free(config->wlan_user_mac);
    free(config->wlan_ac_ip);
    free(config->school_id);
    free(config->domain);
    free(config->area);
}

static int load_codec(const char *path, struct codec *codec)
{
    void *symbol;

    codec->module = dlopen(path, RTLD_NOW | RTLD_LOCAL);
    if (codec->module == NULL) {
        return 0;
    }
    symbol = dlsym(codec->module, "Code");
    memcpy(&codec->code, &symbol, sizeof(codec->code));
    symbol = dlsym(codec->module, "DeCode");
    memcpy(&codec->decode, &symbol, sizeof(codec->decode));
    symbol = dlsym(codec->module, "FreeResult");
    memcpy(&codec->release, &symbol, sizeof(codec->release));
    if (codec->code == NULL || codec->decode == NULL || codec->release == NULL) {
        dlclose(codec->module);
        memset(codec, 0, sizeof(*codec));
        return 0;
    }
    return 1;
}

static void unload_codec(struct codec *codec)
{
    if (codec->module != NULL) {
        dlclose(codec->module);
    }
}

static char *parse_ticket(const char *data)
{
    xmlDocPtr document = xmlReadMemory(data, (int)strlen(data), NULL, NULL,
                                       XML_PARSE_NONET | XML_PARSE_NOERROR);
    xmlNodePtr root;
    char *ticket;

    if (document == NULL) {
        return NULL;
    }
    root = xmlDocGetRootElement(document);
    ticket = find_text(root, "ticket", "Ticket");
    xmlFreeDoc(document);
    return ticket;
}

static char *make_auth_request(const char *user_agent, const char *client_id,
                               const char *user_id, const char *password,
                               const char *ticket)
{
    const char *names[] = {"user-agent", "client-id", "userid", "passwd", "ticket"};
    const char *values[] = {user_agent, client_id, user_id, password, ticket};
    xmlDocPtr document = xmlNewDoc((const xmlChar *)"1.0");
    xmlNodePtr root;
    xmlChar *data = NULL;
    int length = 0;
    char *result;
    size_t index;

    if (document == NULL || (root = xmlNewNode(NULL, (const xmlChar *)"request")) == NULL) {
        xmlFreeDoc(document);
        return NULL;
    }
    xmlDocSetRootElement(document, root);
    for (index = 0; index < sizeof(names) / sizeof(names[0]); ++index) {
        if (xmlNewChild(root, NULL, (const xmlChar *)names[index],
                        (const xmlChar *)values[index]) == NULL) {
            xmlFreeDoc(document);
            return NULL;
        }
    }
    xmlDocDumpMemoryEnc(document, &data, &length, "UTF-8");
    if (data == NULL || length <= 0) {
        xmlFree(data);
        xmlFreeDoc(document);
        return NULL;
    }
    result = strndup((const char *)data, (size_t)length);
    xmlFree(data);
    xmlFreeDoc(document);
    return result;
}

static int auth_succeeded(const char *data, char **message)
{
    xmlDocPtr document = xmlReadMemory(data, (int)strlen(data), NULL, NULL,
                                       XML_PARSE_NONET | XML_PARSE_NOERROR);
    xmlNodePtr root;
    char *code;
    char *status;
    char *error;

    if (document == NULL) {
        return 0;
    }
    root = xmlDocGetRootElement(document);
    code = find_text(root, "code", "result");
    status = find_text(root, "status", "state");
    error = find_text(root, "message", "error");
    if (error != NULL) {
        set_value(message, error);
    }
    if ((code != NULL && strcmp(code, "0") == 0) ||
        (status != NULL && (strcasecmp(status, "success") == 0 ||
                            strcasecmp(status, "online") == 0))) {
        xmlFree(code);
        xmlFree(status);
        xmlFreeDoc(document);
        return 1;
    }
    xmlFree(code);
    xmlFree(status);
    xmlFreeDoc(document);
    return 0;
}

static void print_state(const char *state, const char *detail)
{
    printf("state=%s\n", state);
    if (detail != NULL) {
        printf("detail=%s\n", detail);
    }
}

int main(int argc, char **argv)
{
    struct portal_config config = {0};
    struct codec codec = {0};
    struct buffer response = {0};
    char *password;
    char *ticket;
    char *request;
    char *decoded;
    char *message = NULL;
    const char *client_id;
    const char *user_agent;
    char *current_user_ip;
    char *updated_ticket_url;
    char *cookie = NULL;
    const char *failure = "config-http";
    long status = 0;
    int success = 0;

    if (argc != 3 && argc != 4) {
        fprintf(stderr, "用法: %s [config-url] <protect.so> <userid>\n", argv[0]);
        return EXIT_FAILURE;
    }
    password = getpass("Password: ");
    if (password == NULL) {
        return EXIT_FAILURE;
    }
    client_id = getenv("GD_CLIENT_ID");
    user_agent = getenv("GD_USER_AGENT");
    if (user_agent == NULL) {
        user_agent = "CCTP/Linux64/2.4.64";
    }
    {
        const char *config_url = argc == 3 ? default_config_url : argv[1];
        const char *module_path = argc == 3 ? argv[1] : argv[2];
        const char *user_id = argc == 3 ? argv[2] : argv[3];

    if (http_request(config_url, NULL, user_agent, &response, &status,
                     NULL, &cookie) &&
        parse_config(response.data, &config)) {
        buffer_free(&response);
    } else {
        char *saved_config = read_file("conf/conf.xml");

        failure = "config-fallback";
        buffer_free(&response);
        if (saved_config == NULL || !parse_config(saved_config, &config)) {
            free(saved_config);
            goto finish;
        }
        free(saved_config);
    }
    {
        if (client_id == NULL) {
            client_id = config.client_id != NULL ? config.client_id : "";
        }
        current_user_ip = query_value(config_url, "wlanuserip");
        if (current_user_ip == NULL && argc == 3) {
            current_user_ip = query_value(default_portal_url, "wlanuserip");
        }
        if (current_user_ip != NULL) {
            updated_ticket_url = replace_query_value(config.ticket_url,
                                                     "wlanuserip", current_user_ip);
            if (updated_ticket_url != NULL) {
                free(config.ticket_url);
                config.ticket_url = updated_ticket_url;
            }
            updated_ticket_url = replace_query_value(config.ticket_url,
                                                     "clientip", current_user_ip);
            if (updated_ticket_url != NULL) {
                free(config.ticket_url);
                config.ticket_url = updated_ticket_url;
            }
            free(current_user_ip);
        }
        if (!load_codec(module_path, &codec)) {
            failure = "codec-load";
        } else if (!http_request(config.ticket_url, NULL, user_agent,
                     &response, &status, cookie, &cookie)) {
            failure = "ticket-http";
        } else if ((ticket = parse_ticket(response.data)) == NULL) {
            failure = "ticket-parse";
        } else {
            failure = "auth-request";
            buffer_free(&response);
            request = make_auth_request(user_agent, client_id, user_id, password, ticket);
            if (request == NULL) {
                failure = "auth-xml";
            } else {
                char *encoded = codec.code(request);
                if (encoded == NULL) {
                    failure = "auth-code";
                } else if (!http_request(config.auth_url, encoded, user_agent,
                                         &response, &status, cookie, &cookie)) {
                    failure = "auth-http";
                } else {
                    failure = "auth-decode";
                    decoded = codec.decode(response.data);
                    if (decoded != NULL) {
                        failure = "auth-response";
                        success = auth_succeeded(decoded, &message);
                        codec.release(decoded);
                    }
                    codec.release(encoded);
                }
                free(request);
            }
            free(ticket);
        }
    }
    }
finish:
    if (success) {
        print_state("online", NULL);
    } else {
        print_state("failed", message != NULL ? message : failure);
    }
    free(message);
    free(cookie);
    buffer_free(&response);
    unload_codec(&codec);
    config_free(&config);
    return success ? EXIT_SUCCESS : EXIT_FAILURE;
}