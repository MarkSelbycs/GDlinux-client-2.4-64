# 天翼校园网 Linux 客户端 —— 门户登录（逆向复刻）

本目录是逆向 `ESurfingSvr` 后复刻出的**行为等价、可运行的登录程序**，实现：

```
配置探测 → 申请 ticket → 编码 POST → 解码解析 → 认证(auth) → 解码解析 → 登录状态
```

在原客户端上验证通过：`state=online`，且认证后外网可访问（`www.baidu.com` 返回 HTTP 200）。

---

## 1. 目录结构

```
final/
├── src/
│   └── portal_login.c     # 全部源码（单文件）
├── conf/
│   └── conf.xml           # 运行依赖：客户端保存的配置（urls/clientId/schoolId/domain/area 等）
├── protect.so             # 运行依赖：编码模块（从原客户端捕获，Code/DeCode/FreeResult/...）
├── zxmAlogic.zxm          # 运行依赖：算法容器，程序从中读取 Algo-ID
├── build.sh               # 构建脚本
├── run_login.sh           # 登录（一次性）
├── dynamic.sh             # 动态取配置后登录（index.cgi）
├── logout.sh              # 注销（term.cgi）
├── state.sh               # 查询在线状态（state.cgi）
├── keep.sh                # 登录并保活（keep.cgi）
├── server.sh              # 命名管道服务端（IPC）
├── client.sh              # 命名管道客户端（IPC）
├── portal_login           # 构建产物（build.sh 生成）
└── README.md              # 本文件
```

> `protect.so`、`zxmAlogic.zxm`、`conf/conf.xml` 是运行期依赖，必须与程序保持相对位置。
> 程序需从**本目录**运行（会读取 `conf/conf.xml` 与 `zxmAlogic.zxm`）。

---

## 2. 依赖

### 构建依赖（Linux）

| 依赖 | 用途 | 安装 |
|---|---|---|
| gcc | 编译 C 源码 | `sudo apt install -y build-essential` |
| pkg-config | 定位 libxml2 | `sudo apt install -y pkg-config` |
| libxml2 开发包 | 解析配置/响应 XML | `sudo apt install -y libxml2-dev` |

### 运行依赖

| 依赖 | 说明 |
|---|---|
| glibc | 标准 C 运行库（含 `dlopen`/`getifaddrs`） |
| `protect.so` | 随本目录提供，编码/解码模块 |
| `zxmAlogic.zxm` | 随本目录提供，提供 `Algo-ID` |
| `conf/conf.xml` | 随本目录提供，离线配置回退（网关地址、clientId 等） |

无需 OpenSSL 等第三方库（MD5 已内置于源码中）。

---

## 3. 运行步骤

```bash
cd final

# 1) 构建（只需一次）
sh build.sh

# 2) 运行，按提示在终端输入账号、密码
sh run_login.sh
```

运行示例：

```
Account: <输入你的账号>
Password: <输入密码，不回显>
debug=config ticket-url=http://14.146.227.141:7001/ticket.cgi?...
debug=ticket-http status=200 error=0 bytes=352
debug=ticket-ok length=32
debug=auth-http status=200 error=0 bytes=768
debug=finish result=ok local-ip=172.17.104.130
state=online
```

- 看到 **`state=online`** 即登录成功。
- 关闭诊断输出：`GD_DEBUG=0 sh run_login.sh`。

### 也可直接手动运行

```bash
# 交互式（账号、密码都在终端输入）
GD_DEBUG=1 ./portal_login ./protect.so

# 账号作为参数，密码仍在终端输入
GD_DEBUG=1 ./portal_login ./protect.so <账号>
```

### 退出登录（注销）

```bash
sh logout.sh
```

成功输出 `state=offline`。注销通过向 `term.cgi` 发送编码请求
（`<reason>8</reason>`，字段：user-agent / client-id / ticket / local-time / reason）
实现，与原客户端的 `CPortalConn::TerminalTermRequest` 一致。

> 已注销后重复执行会返回 `term-server`（服务端 `Error-Code: 14`，ticket 已失效），属正常。

### 动态取配置（换校/换网更省心）

```bash
sh dynamic.sh
```

- 原理：GET `<redirect 主机>/index.cgi`，响应里 HTML 注释中内嵌 `<config>`：

  ```xml
  <config><ticket-url>..</ticket-url><auth-url>..</auth-url>
    <state-url>..</state-url><auth><type>..</type></auth>
    <ServerIPs>host:port,host:port</ServerIPs></config>
  ```

- 程序用 `ServerIPs` 选定服务器（优先与本机 `conf.xml` 主机一致的那个），
  替换 ticket / auth / term 的**服务器地址与端口**；查询参数等仍使用本地配置。
- 当前校区实测：由 `ServerIPs` 解析出 `http://14.146.227.141:7001/...`，取票 `Error-Code: 0`。
- 门户配置地址可用 `GD_CONFIG_URL` 覆盖。
- **会话参数**：把网络把你重定向到的**门户 URL** 传给程序，会自动提取
  `wlanacip / wlanuserip / wlanacname / clientmac / paip / vlan / iarmdst / portal_node`
  等参数填入请求：

  ```bash
  sh dynamic.sh 'http://125.88.59.131:10001/qs/index_gz.jsp?wlanacip=183.3.151.148&wlanuserip=172.17.104.132'
  # 或
  GD_PORTAL_URL='http://.../index_gz.jsp?wlanacip=..&wlanuserip=..' sh dynamic.sh
  ```

  - `wlanuserip/clientip` 会被**本机实际源 IP** 覆盖（服务端校验）；
  - `clientmac` 缺失时自动读本机网卡 MAC；
  - 未提供的参数沿用 `conf.xml`。

### 查询在线状态

```bash
sh state.sh
```

- 通过 `state.cgi` 判断当前是否在线：`state=online` 或 `state=offline`。
- 离线时会给出服务端错误码，例如 `detail=server-error=300`（140300 = 等待终端发起认证）。

### 保持在线（保活 keep）

```bash
sh keep.sh
```

登录成功后周期性向 `keep.cgi` 发送编码请求
（字段：user-agent / client-id / ticket / ipv4 / ipv6 / mac / local-time / shared），
间隔由服务端 `<interval>`/`<keep-retry>` 决定；保活失败时输出 `state=offline` 并退出。
按 `Ctrl+C` 手动结束。

### 命名管道 IPC（server / client）

终端 1：
```bash
sh server.sh
```

终端 2：
```bash
sh client.sh connect <账号>    # 回车后提示输入密码
sh client.sh disconnect        # 注销
```

- FIFO：`run/clientpipe`、`run/serverpipe`（可用环境变量 `GD_PIPE_DIR` 更换目录）。
- 消息为 **NUL 结尾的 XML**，与原客户端一致：

  ```xml
  <M><OpS>client</OpS><OpT>Portal</OpT><OpC>PortalConnect</OpC>
     <P><user>..</user><password>..</password></P></M>
  ```

  操作码 `OpC`：`PortalConnect`（登录）、`PortalDisConnect`（注销）。
- 服务端应答：

  ```xml
  <M><OpS>ESurfingSvr</OpS><OpT>PortalState</OpT><OpC>PortalState</OpC>
     <P><state>online|offline|failed</state><detail>..</detail></P></M>
  ```

- 服务端登录成功后自动开始保活定时（空闲到点即发 keep）。

---

## 4. 工作原理（协议要点）

- **配置**：GET `detect.html`；若失败回退读取 `conf/conf.xml`。
- **ticket**：把下列 XML 用 `protect.so` 的 `Code()` 编码，再以 `POST` 发到 `ticket.cgi`：

  ```xml
  <request>
    <host-name>网关主机</host-name><user-agent>CCTP/Linux64/2.4.64</user-agent>
    <client-id>客户端ID</client-id><ipv4>本机IP</ipv4><ipv6></ipv6>
    <mac>本机MAC</mac><local-time>%Y-%m-%d %H:%M:%S</local-time><ostag></ostag>
  </request>
  ```

- **请求头**（关键）：

  ```
  User-Agent / Algo-ID / Client-ID / CDC-Checksum / CDC-SchoolId / CDC-Domain / CDC-Area
  ```

  其中 `CDC-Checksum` = 编码后 body 的 **MD5 小写十六进制**；`Algo-ID` 从 `zxmAlogic.zxm` 读取。

- **响应**：chunked 传输 → 去分块 → `DeCode()` 解码 → 解析 XML
  - ticket 响应：`<response><ticket>..</ticket><expire>..</expire></response>`
  - auth 响应：`<response><userid>..</userid><keep-retry>..</keep-retry>..</response>`

- **客户端 IP**：`wlanuserip` / `clientip` 必须等于**本机网卡 IP**（程序自动探测并替换）。
  用错 IP 会被服务端以 `Error-Code: 10`（无效客户端 IP）拒绝。

- **成功判据**：服务端响应头 `Error-Code == 0` 且 `<response>` 可解析（与原客户端 `CPortalConn::Connect` 一致）。
  注意 `<keep-retry>` 是 keep-alive 重试参数，**不是**错误码。

### 常见服务端 `Error-Code`（对应 `conf/code.xml` 的 1400XX）

| Error-Code | 含义 |
|---|---|
| 0 | 成功 |
| 1 | 无效请求（例如对 ticket.cgi 用 GET） |
| 10 | 无效客户端 IP（本机 IP 与请求参数不一致） |
| 13 | 无效算法 ID（缺少/错误 `Algo-ID` 头） |
| 14 | 无效 ticket |

---

## 5. 更换学校 / 其他校区

已支持较完整的动态化（`--dynamic`）：

| 参数 | 来源 |
|---|---|
| ticket / auth / state / term 服务器与端口 | 门户 `index.cgi` 的 `ServerIPs` |
| `wlanacip` / `wlanacname` / `clientmac` / `paip` / `vlan` / `iarmdst` / `portal_node` | 门户 URL（`GD_PORTAL_URL`），`conf.xml` 兜底 |
| `wlanuserip` / `clientip` | 本机实际源 IP（自动探测） |
| `clientmac` | 门户 URL，缺失时读本机网卡 MAC |
| `clientId` / `schoolId` / `domain` / `area` | 仍来自 `conf.xml` |

换校区用法：

```bash
sh dynamic.sh 'http://<新校区门户>/...?wlanacip=..&wlanuserip=..'
```

未提供的参数沿用 `conf.xml`；若新校区的 `clientId / schoolId / domain / area` 不同，
把它们更新到 `conf/conf.xml` 即可（这几项门户目前不动态下发）。

## 6. 注意事项

- 账号、密码只在本地终端输入，程序不保存、不回显、不打印。
- 必须使用**真实终端**运行（`getpass` 需要 TTY）。
- 必须在 `final/` 目录下运行（程序需从当前目录读取 `zxmAlogic.zxm`）。
- `GD_ALGO_ID` / `GD_ZSM_PATH` 环境变量可覆盖算法 ID / 容器路径（默认自动从 `zxmAlogic.zxm` 读取）。
